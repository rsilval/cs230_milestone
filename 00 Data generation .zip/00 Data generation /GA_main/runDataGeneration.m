function runDataGeneration(problem, params)
% runDataGeneration will sample component fragility modification factors
% from a uniform distribution, evaluate the resulting ATC-138 functional
% recovery time, and store the results in a CSV file for later use.
%
% The function is designed for use in a cluster.

% Problem
CostFunction = problem.CostFunction;
nVar = problem.nVar;
nSys = problem.nSys;
VarSize = [1, nVar];
VarMin = problem.VarMin;
VarMax = problem.VarMax;
systemControl = problem.systemControl;

% Params
MaxIt = params.MaxIt; % Number of data samples desired
nWorkers = params.nWorkers

% Template for Empty Individuals
empty_individual.Position = []; % Store the position
empty_individual.Cost = [];     % Store the cost
empty_individual.RT = [];       % Store the recovery time

mainDir = pwd;

if problem.hpc == 0
    parpool('local', 7)
else
    parpool('local', str2num(getenv('SLURM_CPUS_PER_TASK')))
end

parfor i = 1:nWorkers % Designed to ensure there are always enough temp dirs

    % Create workDir folders using template.
    tempFileName = strcat('workDir_',num2str(i));
    copyfile('templateDir',tempFileName)

end

%% 1 -  Generate "uniform" solutions

    it_hist = [];
    pos_hist = []; % Records the input
    frt_50_hist =[]; % Records the resulting median functional recovery time
    
for i = 1 % Only one set of uniform solutions

    % Reset storage arrays
    
    % Initialization
    pop = repmat(empty_individual, nWorkers, 1);
    pos_hist_data = zeros(length(problem.CapacityDelta), nVar);
    frt_hist_data = zeros(length(problem.CapacityDelta), 1);
    it_hist_data  = zeros(length(problem.CapacityDelta), 1);
    
    parfor cpu = 1:length(problem.CapacityDelta) % Run parallel calculations in different folders
    
        % Evalute fitness function in temporary directory to avoid overlapping
        % access of resources.
        tempFileName = strcat('workDir_',num2str(cpu));
        cd(tempFileName)

        capacity_mod = problem.CapacityDelta(cpu); 

         % Enter modified capcity in design array
         componentMedianRT = [1 * ones(1, 5),  capacity_mod * ones(1, 36)];
         pop(cpu).Position = componentMedianRT;

        % Set baseDir to temporary directory for purposes of evaluating the objective function.  
        baseDir = pwd;

        % Evaluate the objective function in the temporary directory.
        [pop(cpu).Cost pop(cpu).RT pop(cpu).functionality] = CostFunction(pop(cpu).Position, pwd);

        pos_hist_data(cpu,:) = pop(cpu).Position;
        frt_hist_data(cpu) = pop(cpu).RT;
        it_hist_data(cpu) = i;

        % Return to main directory.
        cd(mainDir)

    end
    
    % Store iteration, position, and functional recovery time in the csv
    % data file.
    it_hist = [it_hist; it_hist_data];
    pos_hist = [pos_hist; pos_hist_data]; % Records the input
    frt_50_hist =[frt_50_hist; frt_hist_data]; % Records the resulting median functional recovery time
        
    % Save output as csv file
    fileName = strcat('resultsIP_uni','.csv')
    writematrix([it_hist, pos_hist, frt_50_hist], fileName)     
    
    
end

%% 2 - Generate "one-at-a-time" solutions, component-level
    
    % Reset storage arrays
    it_hist = [];
    pos_hist = []; % Records the input
    frt_50_hist =[]; % Records the resulting median functional recovery time
    
for i = 1:nVar % For each component

    % Initialization
    pop = repmat(empty_individual, nWorkers, 1);
    pos_hist_data = zeros(length(problem.CapacityDelta), nVar);
    frt_hist_data = zeros(length(problem.CapacityDelta), 1);
    it_hist_data  = zeros(length(problem.CapacityDelta), 1);
    
    parfor cpu = 1:length(problem.CapacityDelta) % Run parallel calculations in different folders
    
    % Evalute fitness function in temporary directory to avoid overlapping
    % access of resources.
    tempFileName = strcat('workDir_',num2str(cpu));
    cd(tempFileName)

    capacity_mod = problem.CapacityDelta(cpu); 
        
       % Enter modified capcity in design array
        componentMedianRT = ones(1, problem.nVar);
        componentMedianRT(i) = capacity_mod
        pop(cpu).Position = componentMedianRT;
        
    % Set baseDir to temporary directory for purposes of evaluating the objective function.  
    baseDir = pwd;
    
    % Evaluate the objective function in the temporary directory.
    [pop(cpu).Cost pop(cpu).RT pop(cpu).functionality] = CostFunction(pop(cpu).Position, pwd);
    
    pos_hist_data(cpu,:) = pop(cpu).Position;
    frt_hist_data(cpu) = pop(cpu).RT;
    it_hist_data(cpu) = i;
    
    % Return to main directory.
    cd(mainDir)

    end
    
    % Store iteration, position, and functional recovery time in the csv
    % data file.
    it_hist = [it_hist; it_hist_data];
    pos_hist = [pos_hist; pos_hist_data]; % Records the input
    frt_50_hist =[frt_50_hist; frt_hist_data]; % Records the resulting median functional recovery time
        
    % Save output as csv file
    fileName = strcat('resultsIP_comp','.csv')
    writematrix([it_hist, pos_hist, frt_50_hist], fileName)     
    
    
end

%% 3 - Generate "one-a-time" solutions, system-level
    
% Reset storage arrays
it_hist = [];
pos_hist = []; % Records the input
frt_50_hist =[]; % Records the resulting median functional recovery time
    
for i = 1:nSys % for each system

    % Initialization
    pop = repmat(empty_individual, nWorkers, 1);
    pos_hist_data = zeros(length(problem.CapacityDelta), nVar);
    frt_hist_data = zeros(length(problem.CapacityDelta), 1);
    it_hist_data  = zeros(length(problem.CapacityDelta), 1);
    
    parfor cpu = 1:length(problem.CapacityDelta) % Run parallel calculations in different folders
    
    % Evalute fitness function in temporary directory to avoid overlapping
    % access of resources.
    tempFileName = strcat('workDir_',num2str(cpu));
    cd(tempFileName)

    capacity_mod = problem.CapacityDelta(cpu); 
        
       % Enter modified capcity in design array
        componentMedianRT = ones(1, problem.nVar);
        componentMedianRT(systemControl(i,:) == 1) = capacity_mod;
        pop(cpu).Position = componentMedianRT;
        
    % Set baseDir to temporary directory for purposes of evaluating the objective function.  
    baseDir = pwd;
    
    % Evaluate the objective function in the temporary directory.
    [pop(cpu).Cost pop(cpu).RT pop(cpu).functionality] = CostFunction(pop(cpu).Position, pwd);
    
    pos_hist_data(cpu,:) = pop(cpu).Position;
    frt_hist_data(cpu) = pop(cpu).RT;
    it_hist_data(cpu) = i;
    
    % Return to main directory.
    cd(mainDir)

    end
    
    % Store iteration, position, and functional recovery time in the csv
    % data file.
    it_hist = [it_hist; it_hist_data];
    pos_hist = [pos_hist; pos_hist_data]; % Records the input
    frt_50_hist =[frt_50_hist; frt_hist_data]; % Records the resulting median functional recovery time
        
    % Save output as csv file
    fileName = strcat('resultsIP_sys','.csv')
    writematrix([it_hist, pos_hist, frt_50_hist], fileName)     
    
    
end



%% 4 - Generate "randomized" solutions

for i = 1:MaxIt % each round, generate a random solution

    % Reset storage arrays
    
    parfor cpu = 1:nWorkers % Run parallel calculations in different folders
    
    % Evalute fitness function in temporary directory to avoid overlapping
    % access of resources.
    tempFileName = strcat('workDir_',num2str(cpu));
    cd(tempFileName)



    % Set baseDir to temporary directory for purposes of evaluating the objective function.  
    baseDir = pwd;
    
    % Evaluate the objective function in the temporary directory.
    if mod(cpu,2) == 0
        % Generate Random Solution from uniform distribution for all comps
        pop(cpu).Position = unifrnd(VarMin, VarMax, VarSize);    
    else
        % Generate Random NS ONLY Solution from uniform distribution
        pop(cpu).Position = [ones(1,5), unifrnd(1,3,[1 36])];    
    end
    
    [pop(cpu).Cost pop(cpu).RT pop(cpu).functionality] = CostFunction(pop(cpu).Position, pwd);
    
    pos_hist_data(cpu,:) = pop(cpu).Position;
    frt_hist_data(cpu) = pop(cpu).RT;
    it_hist_data(cpu) = i;
    
    % Return to main directory.
    cd(mainDir)

    end
    
    % Store iteration, position, and functional recovery time in the csv
    % data file.
    it_hist = [it_hist; it_hist_data];
    pos_hist = [pos_hist; pos_hist_data]; % Records the input
    frt_50_hist =[frt_50_hist; frt_hist_data]; % Records the resulting median functional recovery time
        
    % Save output as csv file
    fileName = strcat('resultsIP_rand','.csv')
    writematrix([it_hist, pos_hist, frt_50_hist], fileName)     
    
    
end


end







