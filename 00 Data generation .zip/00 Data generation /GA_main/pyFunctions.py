## Function that modifies JSON component fragility files

import json
import os
from pathlib import Path
import sys

def improveComponents(scale, componentName):

    # Ensure scale always interpreted as a float value
    scale = float(scale)
    
    # Add the (modified) fragility component folder to path
    currpath = Path().absolute()
    os.chdir("Analysis Fragility Data with modifications")

    with open(componentName + '.json','rb') as f:
        file_dict = json.load(f) 

    n_groups = len(file_dict['DSGroups'])
    new_groups_list = []
    print('Initial')
    print(file_dict['DSGroups'][0]['DamageStates'][0]['Consequences']['ReconstructionTime']['Amount'])
    for DSgroup_dict in file_dict['DSGroups']:
        new_damage_state_list = []
        for damage_state in DSgroup_dict['DamageStates']:
            reconstruction_time = damage_state['Consequences']['ReconstructionTime'] 
            amount = reconstruction_time['Amount']
            for i in range(0,len(amount)):
                amount[i] = float(amount[i])*scale
                amount[i] = str(amount[i])
            reconstruction_time['Amount'] = amount
            damage_state['Consequences']['ReconstructionTime'] = reconstruction_time
            new_damage_state_list.append(damage_state)
        DSgroup_dict['DamageStates'] = new_damage_state_list
        new_groups_list.append(DSgroup_dict)

    file_dict['DSGroups'] = new_groups_list
    print('Final')
    print(file_dict['DSGroups'][0]['DamageStates'][0]['Consequences']['ReconstructionTime']['Amount'])

    with open(componentName + '.json','w') as f:
        json.dump(file_dict,f) 


if __name__ == "__main__":
    improveComponents(*sys.argv[1:])
