#!/usr/bin/env python

import os

def mkdir_p(dir):
    '''make a directory (dir) if it doesn't exist'''
    if not os.path.exists(dir):
        os.mkdir(dir)

job_directory = os.getcwd()

# Make top level directories
mkdir_p(job_directory)

max_rand_iterations = [100000]
T_target = [14] # Any number works - Not used in data generation
hazardLevel = [475]
mutationRate = [10] # Any number works -Not used in data generation
percentile = [50]
impedingFactors = [0]
run_number = [1]
hpc_flag = [1]

for it in max_rand_iterations:
    for t in T_target:
        for haz in hazardLevel:
            for mu in mutationRate:
                for perc in percentile:
                    for imp in impedingFactors:
                        for run in run_number:
                            for hpc in hpc_flag:
                                job_name = str(haz)+"yr_"+str(it)+"it_"+"_impFac"+str(imp)+"_"+str(perc)+"percentile"
                                job_file = os.path.join(job_directory, "%s.job" % job_name)
                                with open(job_file,'wb') as fh:
                                    fh.writelines("#!/bin/bash\n")
                                    fh.writelines("#SBATCH --job-name=%s.job\n" % job_name)
                                    fh.writelines("#SBATCH --output=MATLAB_output.log\n")
                                    fh.writelines("#SBATCH --time=96:00:00\n")
                                    fh.writelines("#SBATCH --mem=256000\n")
                                    fh.writelines("#SBATCH --nodes=1\n")
                                    fh.writelines("#SBATCH --ntasks-per-node=1\n")
                                    fh.writelines("#SBATCH --cpus-per-task=32\n")
                                    fh.writelines("#SBATCH --qos=normal\n")
                                    fh.writelines("#SBATCH --partition=cee\n")
                                    fh.writelines("#SBATCH --mail-type=ALL\n")
                                    fh.writelines("#SBATCH --mail-user=oissa@stanford.edu\n")
                                    fh.writelines("ml python/3.6.1\n")
                                    fh.writelines("ml load matlab\n")
                                    fh.writelines("matlab -r \"FRT_GA %s %s %s %s %s %s %s %s\" \n" % (it, t, haz, mu, perc, imp, run, hpc))
                                os.system("sbatch %s" % job_file)

