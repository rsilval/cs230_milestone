%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%   Genetic Algorithms - Main Script
%   Modified by Omar Issa on 08/01/2021
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Sources: 
% Mostapha Kalami Heris, Practical Genetic Algorithms in Python and MATLAB – Video Tutorial 
%(URL: https://yarpiz.com/632/ypga191215-practical-genetic-algorithms-in-python-and-matlab), Yarpiz, 2020.

function [] = FRT_GA(maxIt, T_target, hazardLevel, mu_rate, percentile, impeding_factors, run_number, hpc)

    % Turn warning output off.
    warning('off')

    % Place MATLAB routine in base directory 

    % Copy all contents of GA_main into new one.
    newFolder = strcat(run_number,'_GA_',T_target,'_',maxIt,'_',percentile);
    status = copyfile('GA_main', newFolder, 'f');

    hazardLevel = "475"

    % Change directory to new one.
    cd(newFolder)

    baseDir = pwd;

    % Modify the ComponentDataFolder to current directory.
    data = jsondecode(fileread('input.json'))';

    %% Define problem
    % Decode J SON input file containing performance model
    componentList = fieldnames(data.DamageAndLoss.Components);

    % User should enter the base directory in addition to the target time.
    problem.CostFunction = @(x, baseDir) fitnessFunction(x, baseDir, str2num(T_target),str2num(hazardLevel),str2num(percentile),str2num(impeding_factors), str2num(hpc));
    problem.nVar = length(componentList);
    problem.nSys = 9;
    problem.InitialDesign = ones(1, problem.nVar);

    problem.VarMin = 1 * ones(1, problem.nVar);
    problem.VarMax = [1 * ones(1, 5),  3 * ones(1, 36)];
    problem.CapacityDelta = [1.10 : 0.10 : 3.00]

    problem.systemControl = readmatrix('systemControls.csv');
    problem.hpc = str2num(hpc);

    %% Genetic algorithm parameters
    params.MaxIt = str2num(maxIt);    
    params.nWorkers = max(length(problem.CapacityDelta), problem.nSys);      
    params.beta = 1;        
    params.pC = 1;          
    params.mu = str2num(mu_rate)/100;       % Mutation rate
    params.sigma = 0.1;     

    %% Run GA
    runDataGeneration(problem, params)

end
